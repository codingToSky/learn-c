
package com.lyz.sharding.service;

import com.lyz.sharding.entity.Student;

/**
 * 处理学生的service
 * @author liuyazhuang
 *
 */
public interface StudentService {  

    boolean insert(Student student);  

}  